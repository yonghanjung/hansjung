a = map(int, raw_input().split())
b = map(int, raw_input().split())

for i in range(0,len(a)):
	print a[i] + b[i],




