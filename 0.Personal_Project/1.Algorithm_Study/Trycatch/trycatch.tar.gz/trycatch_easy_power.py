inp = map(int, raw_input().split())
print "%d" %inp[0] ** inp[1]
