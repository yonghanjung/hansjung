a = map(int, raw_input().split())
b = []

for i in a:
	b.append(i+1)
print b
