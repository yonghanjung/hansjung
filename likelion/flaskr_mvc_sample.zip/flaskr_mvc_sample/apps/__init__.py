from flask import Flask

app = Flask('apps')

import flaskr_mvc