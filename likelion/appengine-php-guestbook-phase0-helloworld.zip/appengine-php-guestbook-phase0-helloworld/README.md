appengine-php-guestbook
================================

Guestbook demo for Google App Engine that uses PHP
