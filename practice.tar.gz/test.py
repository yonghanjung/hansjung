import re
import urllib
fileNo = 0
racingGirlUrl = 'http://gall.dcinside.com/list.php?id=racinggirl&no='
for no in range(200000,200010):
        url = racingGirlUrl + str(no)
        f = urllib.urlopen(url)
        html = f.read()
	regex = "http://image.dcinside.com/download.php[^']+"
	pattern = re.compile(regex)
        imageUrlList = re.findall(pattern, html)
        print imageUrlList
        for url in imageUrlList:
                print fileNo
                contents = urllib.urlopen(url).read()
                file(str(fileNo)+'.jpg', 'wb').write(contents)
                fileNo = fileNo + 1
