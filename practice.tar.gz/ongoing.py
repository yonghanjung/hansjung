import gethtml 
import articletext

url = "http://www.nytimes.com/2013/04/10/us/politics/more-senate-republicans-oppose-filibuster-on-gun-bill.html"
print articletext.getArticle(url)
